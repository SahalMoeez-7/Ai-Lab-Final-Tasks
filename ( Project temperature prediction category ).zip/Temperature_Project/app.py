from flask import Flask, render_template, request
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

app = Flask(__name__, template_folder="templates", static_folder="static")

# Dataset load
data = pd.read_csv("temperature_category_dataset.csv")

# Null values fill
for col in data.columns:
    data[col] = data[col].fillna(data[col].mode()[0])

# Categorical columns encode + store labels
cat_columns = data.select_dtypes(include=['object', 'string']).columns
labels = {}

for col in cat_columns:
    data[col], labels[col] = pd.factorize(data[col])

# Features & target
x = data.iloc[:, 0:-1]
y = data.iloc[:, -1]

# Model train
model = RandomForestClassifier()
model.fit(x, y)


@app.route('/')
def home():
    return render_template("index.html")


@app.route('/predict', methods=['POST'])
def predict():
    temp = int(request.form['Temperature'])
    humidity = int(request.form['Humidity'])
    wind = int(request.form['WindSpeed'])

    prediction = model.predict([[temp, humidity, wind]])

    # Convert numeric output back to label
    output = labels[data.columns[-1]][prediction[0]]

    return render_template(
        "index.html",
        prediction_text=f"Predicted Category: {output}"
    )


if __name__ == "__main__":
    app.run(debug=True, port=5001)